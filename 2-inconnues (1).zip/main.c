/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

struct coefficients
{
    double a;
    double b;
    double g;
};
struct point
{
    double x;
    double y;
};

int main()
{
    struct coefficients inc;
    struct point p;
    double num;
    printf("Entrez les coefficients a, b, et g (gain) de votre systeme\n");
    // Entrée des coefficients a, b et g
    printf("a=");
    scanf("%lf",&inc.a);
    printf("b=");
    scanf("%lf",&inc.b);    
    printf("g=");
    scanf("%lf",&inc.g); 
    
    printf("Votre systeme d'équations est:\n(%.2f)x=(%.2f)+(%.2f)\n(%.2f)(y-1)=(%.2f)+(%.2f)",inc.a,inc.a,inc.g,inc.b,inc.a,inc.g);
    
    //Resolution
    num = (inc.b-1)+inc.a+inc.g;
    p.x = (inc.a+inc.g)/inc.a;
    p.y = num/inc.b;
    
    printf("\nLes coordonnées de votre point sont:\nX=%.2f\nY=%.2f",p.x,p.y);

    

    return 0;
}
