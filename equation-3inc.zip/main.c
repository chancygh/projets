/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

struct coefficients
{
    double a;
    double b;
    double c;
    double g;
};
struct mat
{
    double I1;
    double I2;
    double I3;
    double I4;
    double I5;
    double I6;
    double I7;
    double I8;
    double I9;
};
struct mat2
{
    double J1;
    double J2;
    double J3;
};

int main()
{
    struct coefficients inc;
    double det;
    struct mat Min;
    struct mat2 Res;
    
    printf("Entrez les coefficients A, B, C, et G (gain) de votre systeme\n");
    // Entrée des coefficients A, B, C et G
    printf("A=");
    scanf("%lf",&inc.a);
    printf("B=");
    scanf("%lf",&inc.b);    
    printf("C=");
    scanf("%lf",&inc.c);    
    printf("G=");
    scanf("%lf",&inc.g);
    //Affichage de l'equation à résoudre
    
    printf("Votre systeme d'équations est:\nx+y+(%.2f)x=(%.2f)\nx+y+(%.2f)y=(%.2f)\nx+y+(%.2f)z=(%.2f)\n",inc.a,inc.g,inc.b,inc.g,inc.c,inc.g);
   
   //Résolution matricielle
   det = ((inc.a-1)*(inc.b-1)*inc.c)-inc.c;
   printf("det=%.2f",det);
   //Matrice mineure
   Min.I1=(inc.b-1)*inc.c;
   Min.I2=-inc.c;
   Min.I3=inc.b;
   Min.I4=-inc.c;
   Min.I5=inc.c*(inc.a-1);
   Min.I6=(-inc.a);
   Min.I7=0;
   Min.I8=0;
   Min.I9=(inc.a-1)*(inc.b-1)-1;
   
   //Com A
   Min.I1=Min.I1;
   Min.I2=-Min.I2;
   Min.I3=Min.I3;
   Min.I4=-Min.I4;
   Min.I5=Min.I5;
   Min.I6=-Min.I6;
   Min.I7=0;
   Min.I8=-Min.I8;
   Min.I9=Min.I9;
   
   //Resultat 
   Res.J1=(Min.I1/det)*inc.g+(Min.I4/det)*inc.g+(Min.I7/det)*inc.g;
   Res.J2=(Min.I2/det)*inc.g+(Min.I5/det)*inc.g+(Min.I8/det)*inc.g;
   Res.J3=(Min.I3/det)*inc.g+(Min.I6/det)*inc.g+(Min.I9/det)*inc.g;
   
   printf("Les coordonnées de vos points sont:\nX=%.2f\nY=%.2f\nZ=%.2f",Res.J1,Res.J2,Res.J3);

    return 0;
}
