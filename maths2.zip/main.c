/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

  struct coef 
  {
  double a;
  double b;
  double c;
  double d;
  };
 

int main()
{
    struct coef d1,d2,Axyz,n,P,H;
    double deltaX,deltaY,delta,k,num,denum;
    
printf ("Bienvenue dans votre application !\n\n\nSoient deux droites (D1) et (D2) ayant pour equation (D1): a1x1+b1y1+c1=0 et (D2):a2x2+b2y2+c2=0");
//Recupération des coefficients de l'équation de la droite (D1)
printf("\nVeuillez entrer les coefficients (a1,b1,c1) de l'équation de la droite (D1)\n");
printf("a1=");
scanf("%lf",&d1.a);
printf("b1=");
scanf("%lf",&d1.b);
printf("c1=");
scanf("%lf",&d1.c);
//Affichage equation (D1)
printf("\n(D1):(%.2f)x1+(%.2f)y1+(%.2f)=0\n\n",d1.a,d1.b,d1.c);

//Récupération des coefficients de l'équation de la droite (D2)
printf("\n\nVeuillez entrer les coefficients (a1,b1,c1) de l'équation de la droite (D2)\n");
printf("a2=");
scanf("%lf",&d2.a);
printf("b2=");
scanf("%lf",&d2.b);
printf("c2=");
scanf("%lf",&d2.c);
//Affichage equation (D2)
printf("\n(D2):(%.2f)x2+(%.2f)y2+(%.2f)=0",d2.a,d2.b,d2.c);

//Trouvons les coefficients du point A intersection de (D1) et (D2)
//Resoudre le systeme d'équation par la méthode de Cramer
d1.c=-d1.c;
d2.c=-d2.c;
deltaX= (d1.c*d2.b)-(d2.c*d1.b);
deltaY=(d1.a*d2.c)-(d1.c*d2.a);
delta=(d1.a*d2.b)-(d2.a*d1.b);

Axyz.a=deltaX/delta;
Axyz.b=deltaY/delta;
printf("\nLes coordonnées du point A intersection des droites (D1)&(D2) sont:\nA(x,y)=(%.2f,%.2f)",Axyz.a,Axyz.b);

Axyz.c=0,00;

printf("\n\nPassons en 3 dimensions\nA(x,y,z)=(%.2f,%.2f,%.2f)",Axyz.a,Axyz.b,Axyz.c);

//Soit l'equation parametrique de la droite passant par A et perpendiculaire au plan ayant pour equation z=0)

//Etablissons l'equation du plan P
printf("\n\nVeuillez entrer les coefficients (a,b,c,d) de l'équation du plan P\n");
printf("a=");
scanf("%lf",&P.a);
printf("b=");
scanf("%lf",&P.b);
printf("c=");
scanf("%lf",&P.c);
printf("d=");
scanf("%lf",&P.d);
//Affichage equation (P)
printf("\n(P):%.2fx+%.2fy+%.2fz+%.2f=0",P.a,P.b,P.c,P.d);


//Resolvons le systeme d'équations permettant de trouver les coordonnées du projeté H 


num = -(P.a*Axyz.a+P.b*Axyz.b+P.d)-P.c*Axyz.c;
denum = P.c;
k= num/denum;

H.a=Axyz.a; 
H.b=Axyz.b; 
H.c=Axyz.c+k;

printf("\nH(x,y,z)=(%.2f,%.2f,%.2f)",H.a,H.b,H.c);
       
        


    return 0;
}
